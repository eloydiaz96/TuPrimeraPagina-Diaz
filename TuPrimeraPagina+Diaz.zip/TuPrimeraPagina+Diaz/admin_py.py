from django.contrib import admin
from .models import Post, Autor, Categoria

admin.site.register(Post)
admin.site.register(Autor)
admin.site.register(Categoria)